#ifndef __HP5804_H_
#define __HP5804_H_

#include "stdint.h"

#define HP_READ_PT			0x10
#define HP_READ_AT			0x11
#define HP_READ_A				0x31
#define HP_READ_T				0x32
#define HP_READ_P				0x30
#define HP_IIC_ID				APP_I2C_ID_3
#define HP5804_ADDRESS					0xEC>>1
#define HP_P_4096           0x40            //����ѹǿ, ������4096
#define HP_T_4096           0x50            //�����¶�, ������4096

extern float Temp, Pres, Alti;	//�¶�, ѹ��, ����
extern volatile uint8_t I2C1_tdone;
extern volatile uint8_t I2C1_rdone;


uint32_t HP_Read_Pres(void);

uint32_t HP_Read_Temp(void);

long HP_Read_Pres_test(char *pcWriteBuffer, unsigned int xWriteBufferLen, const char *pcCommandString);

#endif


