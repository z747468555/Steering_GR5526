#include "HP5804.h"
#include "app_i2c.h"
#include "SEGGER_RTT.h"
#include "IIC.h"
#include "FreeRTOS_CLI.h"
#define APP_LOG_TAG "hp"
#include "app_log.h"


uint32_t HP_Read_Temp()
{
	uint8_t wdata, rdata[3] = {0, 0, 0};
	uint32_t result;
	wdata = HP_T_4096;
	IIC_Write(HP_IIC_ID, HP5804_ADDRESS, &wdata, 1);
	wdata = HP_READ_T;
	IIC_Write(HP_IIC_ID, HP5804_ADDRESS, &wdata, 1);
	IIC_Read(HP_IIC_ID, HP5804_ADDRESS, rdata, 3);
	
	result = rdata[0];
	result <<= 8;
	result |= rdata[1];
	result <<= 8;
	result |= rdata[2];
	return result;
}


uint32_t HP_Read_Pres()
{
	uint8_t wdata, rdata[3];
	uint32_t result;
	wdata = HP_P_4096;
	IIC_Write_sync(HP_IIC_ID, HP5804_ADDRESS, &wdata, 1);
	wdata = HP_READ_P;
	IIC_Write_sync(HP_IIC_ID, HP5804_ADDRESS, &wdata, 1);
	IIC_Read_sync(HP_IIC_ID, HP5804_ADDRESS, rdata, 3);
	result = rdata[0];
	result <<= 8;
	result |= rdata[1];
	result <<= 8;
	result |= rdata[2];
	return result;
}

long HP_Read_Pres_test(char *pcWriteBuffer, unsigned int xWriteBufferLen, const char *pcCommandString)
{
	uint32_t pres;
	pres = HP_Read_Pres();
	APP_LOG_INFO( "Pressure: %d.%d\r\n",pres/100, pres%100 );
	return 0;
}
