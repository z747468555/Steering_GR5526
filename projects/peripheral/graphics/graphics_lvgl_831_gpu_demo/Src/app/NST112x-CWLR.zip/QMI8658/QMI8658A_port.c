#include "QMI8658A.h"
#include "app_i2c.h"
#include "IIC.h"
#include "SEGGER_RTT.h"
#include "osal_task.h"
#if QMI8658A_SPI_I2C_SEL	
	

/****************** I2c�����ӿ� *******************/

/****************** I2c��ʼ�� *******************/
unsigned char qmi8658a_I2c_Init()
{
	IIC_Init();
	return 0;
}

/****************** I2cд���ݣ����ֽڣ� *******************/
unsigned char qmi8658a_I2c_Write(unsigned char slave_addr,unsigned char reg, unsigned char* data,unsigned char length)
{
	uint16_t ret;
	uint8_t wdata[50];
	wdata[0] = reg;
	memcpy(wdata + 1, data, length);
    ret = app_i2c_transmit_async(QMI_IIC_ID, slave_addr, wdata, length + 1);
    if (ret != APP_DRV_SUCCESS)
    {
        SEGGER_RTT_printf(0, "I2C master send failed.\r\n");
        return 1;
    }
    while(I2C3_tdone == 0);
		I2C3_tdone = 0;
	return 0;
}

/****************** I2c�����ݣ����ֽڣ� *******************/
unsigned char qmi8658a_I2c_Read(unsigned char slave_addr,unsigned char reg,  unsigned char *data,unsigned char length)
{	
    IIC_Write(QMI_IIC_ID, slave_addr, &reg, 1);
    IIC_Read(QMI_IIC_ID, slave_addr, data, length);
	// ret = app_i2c_transmit_async(QMI_IIC_ID, slave_addr, &reg, 1);
    // if (ret != APP_DRV_SUCCESS)
    // {
    //     SEGGER_RTT_printf(0, "I2C master send failed.\r\n");
    //     return 1;
    // }
    // while(g_master_tdone == 0);
	// 	g_master_tdone = 0;
	// ret = app_i2c_receive_async(QMI_IIC_ID, slave_addr, data, length);
    // if (ret != APP_DRV_SUCCESS)
    // {
    //     SEGGER_RTT_printf(0, "I2C master receive failed.\r\n");
    //     return 1;
    // }
    // while(g_master_rdone == 0);
	// 	g_master_rdone = 0;		
	return 0;
}

#else
/****************** SPI�����ӿ� *******************/

unsigned char qmi8658a_Spi_Init(void)
{
	 //user code
}

unsigned char qmi8658a_Spi_Write(unsigned char reg, unsigned char* data,unsigned char length)
{
	//user code
}
unsigned char qmi8658a_Spi_Read(unsigned char reg, unsigned char* data, unsigned char length)
{
	//user code
}

#endif

/****************** ���뼶��ʱ *******************/
void	qmi8658a_delay_ms(unsigned long int ms)
{
	osal_task_delay_ms(ms);
}

